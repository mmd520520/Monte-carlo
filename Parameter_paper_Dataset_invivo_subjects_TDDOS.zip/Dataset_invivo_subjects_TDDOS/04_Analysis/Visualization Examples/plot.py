import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#load data
data = pd.read_csv("Results_Final.txt", sep = "\t")

#filter according to the requirements
filtered_data = data[(data['Subject'] == 'Subject1') & 
                     (data['Location'] == 'Upper_arm') & 
                     (data['Measure'] == 'Rep1') &
                     (data['Lab06'] == 2)]

#plot
plt.plot(filtered_data["Lambda"], filtered_data["VarMua0Opt"])
plt.ylabel(r"$\mu_a$ [cm$^{-1}$]") 
plt.xlabel("wavelength [nm]")
plt.show()

plt.plot(filtered_data["Lambda"], filtered_data["VarMus0Opt"]) 
plt.ylabel(r"$\mu_s'$ [cm$^{-1}$]") 
plt.xlabel("wavelength [nm]")
plt.show()

#if needed for faster computation store the data in numpy
wavelengths = np.array(filtered_data["Lambda"])
mu_a = np.array(filtered_data["VarMua0Opt"])
mu_s = np.array(filtered_data["VarMus0Opt"])

