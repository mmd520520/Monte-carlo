function [header,data] = read_dat_matlab(inputFile)

% Reads .DAT format files and extracts header information and data.
% Parameters:
%    inputFile (str): The name of the .DAT file to read.
%    headerSize (int, optional): Header size. Default is 764.
%    subheaderSize (int, optional): Subheader size. Default is 204.
%    nChannels (int, optional): Number of channels in the TCSPC board. Default is 4096.
%
% Returns:
%    header (DataFrame): DataFrame containing header information.
%    Curves (ndarray): matrix of size m*n containing the curves
%                      m = number of curves
%                      n = number of channels
% Plot logarithamically the values of a row to obtain the corresponding temporal point spread function.
% The data is structured as 'm' curves recorded consecutively with the experimental
% parameters varying as per the loops defined by the experiment operator and are given 
% in the header as follows - 
%        
%            "LoopBegin": (i1 i2 i3)
%              "LoopEnd": (f1 f2 f3)
%             "Stepsize": (d1 d2 d3)
%       "IterationCount": (n1 n2 n3)
%       
% with i3:f3:d3 being the innermost loop for acquiring the data curves.

    % Default values for optional parameters
    if nargin < 4
        nChannels = 4096;
    end
    if nargin < 3
        subheaderSize = 204;
    end
    if nargin < 2
        headerSize = 764;
    end

    % File parameters
    headerType = 'uint8';
    subheaderType = 'uint8';
    dataType = 'uint16';
    nChannels = 4096;
    headerSize=764;
    subheaderSize=204;
    
    % Open data file.
    fidIn = fopen(inputFile, 'r');
    fsize = dir(inputFile)
    nCurves = ceil((fsize.bytes-headerSize-subheaderSize)/(subheaderSize+2*nChannels))
    
    % Check if the file was opened successfully
    if fidIn == -1
        error('Failed to open the file.');
    end

    % Initialize data matrix.
    data = zeros(nCurves, nChannels);

    % Preallocate arrays for header decoding
    h_name = cell(13, 1);
    h_val = cell(13, 1);

    % Header decoding
    fread(fidIn, 6, 'int32')
    h_name{1} = '*Device S/N';
    h_val{1} = fread(fidIn, 1, 'int32');
    h_name{2} = '*FW Version';
    h_val{2} = fread(fidIn, 1, 'int32');
    h_name{3} = '*SW Version';
    h_val{3} = fread(fidIn, 1, 'int32');
    h_name{4} = '*Date';
    h_val{4} = char(fread(fidIn, 11, 'char'))';
    h_name{5} = '*Time';
    h_val{5} = char(fread(fidIn, 9, 'char'))';
    fread(fidIn, 3, 'int32')
    h_name{6} = '*LoopFirst';
    h_val{6} = fread(fidIn, 3, 'int32')';
    h_name{7} = '*LoopLast';
    h_val{7} = fread(fidIn, 3, 'int32')';
    h_name{8} = '*StepSize';
    h_val{8} = fread(fidIn, 3, 'int32')';
    h_name{9} = '*IterationCount';
    h_val{9} = fread(fidIn, 3, 'int32')';
    h_name{10} = '*ChannNum';
    h_val{10} = fread(fidIn, 1, 'int32');
    h_name{11} = '*PageNum';
    h_val{11} = fread(fidIn, 1, 'int32');
    fread(fidIn, 2, 'int32')
    h_name{12} = '*Int Time';
    h_val{12} = fread(fidIn, 1, 'double');
    h_name{13} = '*BinSize';
    h_val{13} = fread(fidIn, 1, 'double');

    % Read curves. Every curve is preceded by a subheader.
    for curveIdx = 1:nCurves
        fread(fidIn, subheaderSize, subheaderType);
        data(curveIdx,:) = fread(fidIn, nChannels, dataType);
    end

    % Create a header DataFrame
    header = table(h_name, h_val, 'VariableNames', {'Field_name', 'Field_value'});

    % To plot a sample curve
    semilogy(data(10,:))

    fclose(fidIn);
end


