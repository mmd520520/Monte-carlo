import os
import math
import struct
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def read_dat_python(filename, headerSize=764, subheaderSize=204, nChannels=4096):
    """
    Reads .DAT format files and extracts header information and data.
    The .DAT files are binary encoded files beginning with a header, followed by a pair of sunheader

    Parameters:
        filename (str): The name of the .DAT file to read.
        headerSize (int, optional): Header size. Default is 764.
        subheaderSize (int, optional): Subheader size. Default is 204.
        nChannels (int, optional): Number of channels in the TCSPC board. Default is 4096.

    Returns:
        header (pd.DataFrame): DataFrame containing header information.
        data (np.ndarray): Numpy array of size m*n containing all the curves, where,
          m = number of curves
          n = number of channels
        Plotting logarithmically each of the 260 inner arrays (rows) gives us the curves
        
    The data is structured as 'm' curves recorded consecutively with the experimental
    parameters varying as per the loops defined by the experiment operator and are given 
    in the header as follows - 
    
             "LoopBegin": (i1 i2 i3)
               "LoopEnd": (f1 f2 f3)
              "Stepsize": (d1 d2 d3)
        "IterationCount": (n1 n2 n3)
        
    with i3:f3:d3 being the innermost loop for acquiring the data curves.

    """
    #Open the .DAT file and obtain the size to calculate number of curves
    with open(filename, 'rb') as input_file:
        size = os.stat(filename).st_size
        nCurves = math.ceil((size - headerSize - subheaderSize)/(subheaderSize + nChannels * 2))

        #Initialize Numpy array to store the curves
        data = np.empty((nCurves,nChannels), dtype=np.uint16)

        #Read and store the header
        header = input_file.read(headerSize)
        
        #Read the curves and store in numpy array
        for i in range(nCurves):
            input_file.read(subheaderSize)
            curve_array = np.fromfile(input_file, dtype=np.uint16, count=nChannels)
            data[i] = curve_array

    h_name = []
    h_val = []

    # Header decoding
    h_name.append('*Device S/N')
    h_val.append(struct.unpack('@l', header[24:28])[0])
    h_name.append('*FW Version')
    h_val.append(struct.unpack('@l', header[28:32])[0])
    h_name.append('*SW Version')
    h_val.append(struct.unpack('@l', header[32:36])[0])
    h_name.append('*Date')
    h_val.append(struct.unpack('@ccccccccccc', header[36:47]))
    h_val[3] = b''.join(h_val[3][0:10]).decode('utf-8')
    h_name.append('*Time')
    h_val.append(struct.unpack('@ccccccccc', header[47:56]))
    h_val[4] = b''.join(h_val[4][0:8]).decode('utf-8')
    h_name.append('*LoopBegin')
    h_val.append(struct.unpack('@lll', header[68:80]))
    h_name.append('*LoopEnd')
    h_val.append(struct.unpack('@lll', header[80:92]))
    h_name.append('*StepSize')
    h_val.append(struct.unpack('@lll', header[92:104]))
    h_name.append('*IterationCount')
    h_val.append(struct.unpack('@lll', header[104:116]))
    h_name.append('*ChannNum')
    h_val.append(struct.unpack('@l', header[116:120])[0])
    h_name.append('*PageNum')
    h_val.append(struct.unpack('@l', header[120:124])[0])
    h_name.append('*IntTime')
    h_val.append(struct.unpack('@d', header[132:140])[0])
    h_name.append('*BinSize')
    h_val.append(struct.unpack('@d', header[140:148])[0])
    
    #Write the header as a dataframe
    header_out = pd.DataFrame({'Field name': h_name, 'Field value': h_val})
    
    #Plot a single sample curve
    # plt.semilogy(data[0])

    return header_out, data
