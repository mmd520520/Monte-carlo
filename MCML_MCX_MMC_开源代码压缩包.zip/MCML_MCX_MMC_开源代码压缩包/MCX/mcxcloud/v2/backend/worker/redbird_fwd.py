#!/usr/bin/env python3
"""MCX Cloud v2 redbird worker: minimal FEM diffusion forward solve.

Reads the SAME mcxcloud JSON input that mcx/mmc consume (input.json in the CWD),
builds a redbirdpy cfg from it, runs a single-wavelength CW/RF forward solve, and
writes the nodal fluence to output.jnii (JNIfTI) + detector readings to
output_detp.jdat.

Deliberately minimal: single wavelength, fixed optical properties, forward only.
Reconstruction, multi-spectral and microwave (Helmholtz) modes are out of scope and
are not reachable from the mcxcloud schema.

Field mapping (mcxcloud/mmc JSON -> redbird cfg):
  Shapes.MeshNode        -> cfg['node']   (Nn x 3)
  Shapes.MeshElem        -> cfg['elem']   passed through with its 5th (label) column;
                            redbirdpy's meshprep() splits that into cfg['seg'] itself,
                            exactly as rbmeshprep.m does. redbirdpy keeps 1-BASED
                            indices, same as the JSON/mmc convention, so no rebasing.
  Domain.Media           -> cfg['prop']   1:1, no conversion: redbird's prop is also
                            [mua, mus, g, n] with RAW mus (reduced internally as
                            musp = mus*(1-g)), and seg indexes it 0-based (prop[seg])
                            exactly like mmc's elemprop.
  Optode.Source.Pos/Dir  -> cfg['srcpos'] / cfg['srcdir']
  Optode.Detector[].Pos  -> cfg['detpos']
  Forward.Omega          -> cfg['omega']  (rad/s, 0 = CW; the backend derives this from
                            the canonical Optode.Source.Frequency in Hz)
"""

import base64
import json
import sys
import time
import zlib

import numpy as np

import redbirdpy as rb
from redbirdpy.utility import getdetdir, meshprep

# JData _ArrayType_ -> numpy dtype (mirrors the frontend's util.js TYPED table)
JD_TYPES = {
    "uint8": np.uint8, "int8": np.int8,
    "uint16": np.uint16, "int16": np.int16,
    "uint32": np.uint32, "int32": np.int32,
    "single": np.float32, "float32": np.float32,
    "double": np.float64, "float64": np.float64,
}


def jd_decode(node):
    """Decode a JData-annotated array node (or pass a plain list through).

    mcxcloud reassembles large mesh arrays into JData form, which may be
    zlib/gzip+base64 packed (_ArrayZipData_). Both codecs are Python stdlib, so unlike
    the Octave path this needs no zmat/zlib mex.
    """
    if not isinstance(node, dict):
        return np.asarray(node)
    dtype = JD_TYPES.get(node.get("_ArrayType_"), np.float64)
    size = node.get("_ArraySize_")
    if "_ArrayZipData_" in node:
        raw = base64.b64decode(node["_ArrayZipData_"])
        zt = str(node.get("_ArrayZipType_", "zlib")).lower()
        buf = zlib.decompress(raw, 16 + zlib.MAX_WBITS) if zt == "gzip" else zlib.decompress(raw)
        arr = np.frombuffer(buf, dtype=dtype)
    else:
        arr = np.asarray(node.get("_ArrayData_", []), dtype=dtype).ravel()
    # The packed buffer is flattened ROW-MAJOR (verified against a known mesh bbox:
    # C-order recovers the true extents, Fortran order scrambles the columns), so the
    # logical shape is _ArraySize_ read in C order. _ArrayZipSize_ describes only the
    # pre-flatten BUFFER layout -- notably [2, numel] for complex (real row, imag row) --
    # and must NOT be used as the output shape.
    if node.get("_ArrayIsComplex_"):
        half = arr.size // 2
        arr = arr[:half] + 1j * arr[half:]
    if size:
        arr = arr.reshape(tuple(int(x) for x in size))
    return np.array(arr)  # writable copy (frombuffer is read-only)


def rows(v, ncol=3):
    """Force a JSON coordinate list into an (N, ncol) array.

    JSON gives [x,y,z] as a flat 3-list and [[..],[..]] as nested; a single row must
    not be reinterpreted as a column of 3 separate optodes.
    """
    a = np.atleast_2d(np.asarray(jd_decode(v), dtype=float))
    if a.shape[0] == ncol and a.shape[1] == 1:
        a = a.T
    return a[:, :ncol]


def media_to_prop(media):
    """Domain.Media (list of {mua,mus,g,n} objects or [mua,mus,g,n] rows) -> (N,4)."""
    if isinstance(media, dict):
        media = [media]
    out = []
    for m in media:
        if isinstance(m, dict):
            out.append([m["mua"], m["mus"], m["g"], m["n"]])
        else:
            out.append(list(np.asarray(m, dtype=float).ravel()[:4]))
    return np.asarray(out, dtype=float)


#: numpy dtype -> JData _ArrayType_ name
JD_NAMES = {
    "float32": "single", "float64": "double",
    "int8": "int8", "uint8": "uint8", "int16": "int16", "uint16": "uint16",
    "int32": "int32", "uint32": "uint32", "int64": "int64", "uint64": "uint64",
}


def annotate(arr):
    """Wrap a numpy array as an uncompressed JData-annotated node.

    Flattened ROW-MAJOR, which is what the JData spec means by the flattened form and
    what jsonlab's loadjson/jdatadecode assumes (verified by decoding a jsonlab-written
    mesh: read row-major it reproduces the true node coordinates, read column-major the
    coordinates scramble). Getting this wrong would silently corrupt the mesh for anyone
    opening the file with loadjmesh, so the wire format follows the spec and the frontend
    adapts at its own boundary instead.

    Integer arrays keep an integer _ArrayType_ and integer values -- element connectivity
    and tissue labels are indices, not measurements. Uncompressed _ArrayData_ keeps the
    file readable and needs no zmat/zlib on either side.
    """
    a = np.asarray(arr)
    flat = a.ravel(order="C")
    name = JD_NAMES.get(str(a.dtype), "double")
    vals = [int(x) for x in flat] if np.issubdtype(a.dtype, np.integer) else [float(x) for x in flat]
    return {"_ArrayType_": name, "_ArraySize_": list(a.shape), "_ArrayData_": vals}


def main():
    with open("input.json") as fp:
        cfgin = json.load(fp)

    mesh = cfgin.get("Shapes") or cfgin.get("Mesh")
    if not isinstance(mesh, dict) or "MeshNode" not in mesh or "MeshElem" not in mesh:
        sys.exit("redbird: input requires Shapes.MeshNode + Shapes.MeshElem (a tet mesh)")

    cfg = {}
    cfg["node"] = jd_decode(mesh["MeshNode"])[:, :3].astype(float)
    # keep the label column: meshprep() splits it into cfg['seg'] the way mmc uses col 5.
    # int, not float: pyiso2mesh indexes node[] with these directly (elemvolume/meshreorient)
    # and rejects a float index array, unlike MATLAB where everything is a double.
    elem = jd_decode(mesh["MeshElem"])
    cfg["elem"] = elem.astype(int)
    if elem.shape[1] <= 4:
        cfg["seg"] = np.ones(elem.shape[0], dtype=int)

    cfg["prop"] = media_to_prop(cfgin["Domain"]["Media"])

    src = cfgin["Optode"]["Source"]
    cfg["srcpos"] = rows(src["Pos"])
    cfg["srcdir"] = rows(src["Dir"])

    dets = cfgin.get("Optode", {}).get("Detector") or []
    if isinstance(dets, dict):
        dets = [dets]
    detpos = [rows(d["Pos"])[0] for d in dets if isinstance(d, dict) and "Pos" in d]
    if detpos:
        cfg["detpos"] = np.asarray(detpos, dtype=float)
    else:
        # femrhs needs at least one detector column; a centroid probe keeps a
        # detector-less input runnable (the nodal fluence field is what matters)
        cfg["detpos"] = cfg["node"].mean(axis=0, keepdims=True)
        print("[redbird] no detectors given; probing the mesh centroid", flush=True)
    # mcxcloud mesh detectors only carry {Pos, R} (no direction), but getoptodes pushes
    # each optode one transport mean free path INWARD along its dir -- synthesize the
    # inward surface normals. Slice to 3 cols (getdetdir returns Nd x 4: normal + focus).
    cfg["detdir"] = np.asarray(getdetdir(cfg))[:, :3]

    cfg["omega"] = float(cfgin.get("Forward", {}).get("Omega", 0) or 0)

    nsrc = cfg["srcpos"].shape[0]
    print(
        "[redbird] %d nodes, %d elems, %d src, %d det, omega=%g rad/s"
        % (cfg["node"].shape[0], cfg["elem"].shape[0], nsrc, cfg["detpos"].shape[0], cfg["omega"]),
        flush=True,
    )

    t0 = time.time()
    cfg, _ = meshprep(cfg)

    # cfg['evol'] (element volumes) and cfg['deldotdel'] scale the FEM volume integrals, so a
    # uniformly NEGATED evol negates the whole stiffness matrix, giving an indefinite system
    # whose "solution" is sign-flipped oscillatory garbage -- about half the nodes negative,
    # with the fluence peak far from the source. This is silent: nothing errors.
    #
    # meshreorient is meant to normalize element winding, but the iso2mesh Python port can
    # settle on a winding that its own signed-volume measure then calls negative, where the
    # MATLAB one yields positive. Measured on the twolayerslab demo: all 81000 evol entries
    # negative and A's diagonal exactly the negation of redbird-matlab's. Re-flipping the
    # input winding does NOT help (meshreorient just re-normalizes it back), so correct the
    # derived quantities instead. With evol and deldotdel negated, the solve reproduces
    # redbird-matlab to 4 significant figures (peak at the source, 1 negative node of 15376).
    #
    # Only a UNIFORM inversion is a convention mismatch and safe to correct this way; mixed
    # signs mean a genuinely broken mesh, so refuse rather than guess.
    evol = np.asarray(cfg.get("evol", [])).ravel()
    if evol.size and np.any(evol < 0):
        if not np.all(evol < 0):
            sys.exit("redbird: mesh has %d of %d inverted elements (mixed orientation); "
                     "refusing to solve on it" % (int((evol < 0).sum()), evol.size))
        print("[redbird] all %d element volumes negative (iso2mesh winding convention); "
              "correcting evol/deldotdel sign" % evol.size, flush=True)
        cfg["evol"] = -evol
        cfg["deldotdel"] = -np.asarray(cfg["deldotdel"])
        nvol = np.asarray(cfg.get("nvol", [])).ravel()
        if nvol.size and np.all(nvol < 0):
            cfg["nvol"] = -nvol
    print("[redbird] mesh prep ... %.3f s" % (time.time() - t0), flush=True)

    t0 = time.time()
    out = rb.runforward(cfg)
    print("[redbird] forward solve ... %.3f s" % (time.time() - t0), flush=True)
    detphi, phi = out[0], out[1]

    # femrhs builds one RHS column per source AND one per detector (detectors double as
    # adjoint sources), so phi is Nn x (Nsrc+Ndet) -- keep only the forward source columns.
    phi = np.asarray(phi)
    if phi.ndim == 1:
        phi = phi[:, None]
    phi = phi[:, :nsrc]
    if np.iscomplexobj(phi):
        # RF (omega>0) gives a complex field; store the amplitude, which is what the
        # preview renders. The complex detector readings are preserved in detphi below.
        print("[redbird] complex (RF) field: saving amplitude", flush=True)
        phi = np.abs(phi)

    # Sanity-check the solution before publishing it. A diffusion fluence is physically
    # non-negative; a converged FEM solve shows only tiny numerical undershoot near zero
    # (measured min/max ratios of -2e-6 .. -1.6e-8 on known-good solves). A failed/singular
    # solve instead oscillates, with ~50% of nodes negative and |min| comparable to (or
    # wildly exceeding) max. Without this check such a solve is published as a normal
    # "completed" job and the garbage is indistinguishable from a real result in the UI.
    fmax = float(np.max(phi)) if phi.size else 0.0
    if not np.all(np.isfinite(phi)):
        sys.exit("redbird: solution contains non-finite values (failed linear solve)")
    if fmax <= 0:
        sys.exit("redbird: solution has no positive fluence (failed linear solve)")
    fmin = float(np.min(phi))
    negfrac = float(np.mean(phi < -1e-6 * fmax))
    if fmin < -1e-2 * fmax or negfrac > 0.05:
        sys.exit(
            "redbird: solution is not a valid fluence field -- min=%.3e max=%.3e "
            "(%.1f%% of nodes negative). This indicates the linear solve did not converge; "
            "refusing to publish it." % (fmin, fmax, 100 * negfrac)
        )

    phi = phi.astype(np.float32)

    # ---- the fluence field, as JMesh (.jmsh) ---------------------------------
    # NOT JNIfTI: .jnii describes a NIfTI-like voxel volume, and this field lives on the
    # nodes of a tetrahedral mesh. JMesh is the mesh-native container (JMesh spec /
    # iso2mesh savejmesh.m): a mesh container may be a bare array or a structure with a
    # required "Data" plus optional "Properties", where vertex objects carry per-vertex
    # values under Properties.Value. Writing the mesh alongside the values also makes the
    # output self-contained -- readable and renderable without the original input file.
    elem_out = np.asarray(cfg["elem"])
    jmsh = {
        "_DataInfo_": {
            "JMeshVersion": "0.5",
            "Comment": "Redbird FEM diffusion forward solution (nodal fluence)",
            "Engine": "redbird",
            "SrcNum": int(nsrc),
            "Omega": float(cfg["omega"]),
        },
        # Nn x 3 coordinates + Nn x Nsrc nodal fluence (one column per source)
        "MeshVertex3": {
            "Data": annotate(np.asarray(cfg["node"], dtype=np.float32)),
            "Properties": {"Value": annotate(phi)},
        },
        # Ne x 4 connectivity (1-based) + the per-element tissue label
        "MeshTet4": {
            "Data": annotate(elem_out[:, :4].astype(np.int32)),
            "Properties": {"Value": annotate(np.asarray(cfg["seg"]).reshape(-1, 1).astype(np.int32))},
        },
    }
    with open("output.jmsh", "w") as fp:
        json.dump(jmsh, fp)

    # ---- the detector readings ------------------------------------------------
    # Mirrors the MCXData/Info/PhotonData shape mcx and mmc emit, but this is NOT a
    # detected-photon list: Redbird traces no photons. detphi is the deterministic
    # Ndet x Nsrc forward measurement matrix, so it goes under "Measurement" with an Info
    # header that says how to read it (complex when Omega > 0, split into real/imag parts
    # since JSON has no complex scalar).
    dp = np.asarray(detphi)
    if dp.ndim == 1:
        dp = dp.reshape(-1, 1)
    info = {
        "Version": 1,
        "Engine": "redbird",
        "SrcNum": int(nsrc),
        "DetNum": int(dp.shape[0]),
        "Omega": float(cfg["omega"]),
        "IsComplex": bool(np.iscomplexobj(dp)),
        "Unit": "1/mm^2",
    }
    meas = {"detphi": annotate(np.abs(dp) if np.iscomplexobj(dp) else dp)}
    if np.iscomplexobj(dp):
        meas["detphi_real"] = annotate(np.real(dp))
        meas["detphi_imag"] = annotate(np.imag(dp))
    with open("output_detp.jdat", "w") as fp:
        json.dump({"RedbirdData": {"Info": info, "Measurement": meas}}, fp)

    print(
        "[redbird] wrote output.jmsh (%d nodes x %d src) + output_detp.jdat (%d det x %d src)"
        % (phi.shape[0], phi.shape[1], dp.shape[0], dp.shape[1]),
        flush=True,
    )


if __name__ == "__main__":
    main()
