# Copyright (c) 2023-2025 Qianqian Fang (q.fang <at> neu.edu)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


"""Reading and writing MCX data files.

* :func:`loadmc2`, :func:`loadmch`, :func:`loadnii`, :func:`loadfile`: read the volume
  (``.mc2``, ``.nii``, ``.jnii``, ``.bnii``) and detected photon (``.mch``) outputs of MCX
* :func:`mcx2json`, :func:`json2mcx`: convert between a ``cfg`` dict and the JSON input
  file of the ``mcx`` command line
"""

__all__ = (
    "loadmc2",
    "loadmch",
    "loadfile",
    "mcx2json",
    "json2mcx",
    "loadnii",
)

##====================================================================================
## dependent libraries
##====================================================================================

import struct
import os
import re
import warnings
import json
import numpy as np

##====================================================================================
## implementation
##====================================================================================


def loadmc2(fname, dim, dataformat="float", offset=None):
    """Read a binary volume output (``.mc2``) of MCX.

    Parameters
    ----------
    fname : str
        The file name.
    dim : list or tuple
        The shape of the data, normally ``[nx, ny, nz, nt]``; the file stores x fastest
        (column-major), as mcx writes it and as ``pmcx.run`` returns it.
    dataformat : str, optional
        The data type: ``'float'`` (default), ``'float32'``, ``'single'``, ``'double'``,
        ``'float64'``, ``'uchar'``, ``'uint8'``, ``'int8'``, ``'uint16'``, ``'int16'``,
        ``'uint32'``, ``'int32'``, ``'uint64'`` or ``'int64'``; a MATLAB-style
        ``'float=>float'`` uses its input type.
    offset : int, optional
        Number of bytes to skip at the beginning of the file.

    Returns
    -------
    data : ndarray
        The data, of shape ``dim``. When diffuse reflectance was recorded, it is stored as
        negative values in the layer of voxels next to the domain.

    Raises
    ------
    ValueError
        If the data type is not supported.
    IOError
        If the file can not be opened.
    """

    # Map MATLAB format strings to NumPy dtypes
    format_map = {
        "float": np.float32,
        "single": np.float32,
        "double": np.float64,
        "uchar": np.uint8,
        "uint8": np.uint8,
        "int8": np.int8,
        "uint16": np.uint16,
        "int16": np.int16,
        "uint32": np.uint32,
        "int32": np.int32,
        "uint64": np.uint64,
        "int64": np.int64,
    }

    # Handle MATLAB-style format strings (e.g., 'uchar=>uchar', 'float=>float')
    if "=>" in dataformat:
        dataformat = dataformat.split("=>")[0]  # Use the input format part

    if dataformat not in format_map:
        raise ValueError(f"Unsupported format: {dataformat}")

    dtype = format_map[dataformat]

    # Open file and read data
    try:
        fid = open(fname, "rb")
    except IOError:
        raise IOError("can not open the specified file")

    if offset is not None:
        fid.seek(offset, 0)  # 0 corresponds to 'bof' (beginning of file)

    # Read all data from file
    file_data = fid.read()
    data = np.frombuffer(file_data, dtype=dtype)
    fid.close()

    # Reshape data according to specified dimensions
    data = data.reshape(dim, order="F")  # mcx writes x fastest, as loadmc2.m reads

    return data


def loadmch(fname, dataformat="float32", endian="little"):
    """Read a detected photon file (``.mch``) of MCX.

    Parameters
    ----------
    fname : str
        The file name.
    dataformat : str, optional
        The data type of the records: ``'float32'`` (default), ``'float'``, ``'single'``,
        ``'double'``, ``'uint'``, ``'int'``, ``'uchar'`` or ``'char'``.
    endian : {'little', 'big'}, optional
        The byte order of the file (default ``'little'``).

    Returns
    -------
    data : ndarray, shape (nphoton, ncol)
        One row per detected photon, in the column order
        ``[detid(1) nscat(M) ppath(M) mom(M) p(3) v(3) w0(1) s(4)]``, where ``M`` is the
        number of media and only the fields of ``savedetflag`` are present; the partial
        path lengths are converted to mm.
    header : dict
        The file header: ``version``, ``medianum``, ``detnum``, ``recordnum``,
        ``totalphoton``, ``detectedphoton``, ``savedphoton``, ``lengthunit``, ``seedbyte``,
        ``normalizer``, ``respin``, ``srcnum``, ``savedetflag`` and ``totalsource``.
    photonseed : ndarray, shape (nphoton, seedbyte), uint8
        Returned only when the file has a seed section: the RNG state of each detected
        photon, which replays it with the same RNG (``cfg['seed']``).

    Raises
    ------
    ValueError
        If the data type or the file version is not supported.
    RuntimeError
        If the file has no MCX detected photon data block.
    IOError
        If the file can not be opened.
    """

    # Handle format string (remove '=>' part if present)
    if "=>" in dataformat:
        dataformat = dataformat.split("=>")[0]

    # Map format strings to numpy dtypes
    format_map = {
        "float32": np.float32,
        "float": np.float32,
        "single": np.float32,
        "double": np.float64,
        "uint": np.uint32,
        "int": np.int32,
        "uchar": np.uint8,
        "char": np.int8,
    }

    if dataformat not in format_map:
        raise ValueError(f"Unsupported format: {dataformat}")

    dtype = format_map[dataformat]

    # Set endian character for struct format
    endian_char = "<" if endian == "little" else ">"

    try:
        fid = open(fname, "rb")
    except IOError:
        raise IOError("can not open the specified file")

    data = []
    header = []
    photonseed = []
    seedbyte = 0
    normalizer = 0
    respin = 0
    srcnum = 0
    savedetflag = 0
    totalsource = 0

    # Read file in chunks looking for MCXH magic headers
    while True:
        try:
            # Try to read magic header
            magicheader = fid.read(4)
            if len(magicheader) < 4:
                break

            if magicheader != b"MCXH":
                if len(header) == 0:
                    fid.close()
                    raise RuntimeError("can not find a MCX history data block")
                break

            # Read header data: version, maxmedia, detnum, colcount, totalphoton, detected, savedphoton
            hd_data = fid.read(7 * 4)  # 7 uint32 values
            if len(hd_data) < 28:
                break
            hd = list(struct.unpack(endian_char + "7I", hd_data))

            if hd[0] != 1:
                raise ValueError("version higher than 1 is not supported")

            # Read additional header fields
            unitmm_data = fid.read(4)
            unitmm = struct.unpack(endian_char + "f", unitmm_data)[0]

            seedbyte_data = fid.read(4)
            seedbyte = struct.unpack(endian_char + "I", seedbyte_data)[0]

            normalizer_data = fid.read(4)
            normalizer = struct.unpack(endian_char + "f", normalizer_data)[0]

            respin_data = fid.read(4)
            respin = struct.unpack(endian_char + "i", respin_data)[0]

            srcnum_data = fid.read(4)
            srcnum = struct.unpack(endian_char + "I", srcnum_data)[0]

            savedetflag_data = fid.read(4)
            savedetflag = struct.unpack(endian_char + "I", savedetflag_data)[0]

            totalsource_data = fid.read(4)
            totalsource = struct.unpack(endian_char + "I", totalsource_data)[0]

            # Skip junk field
            junk_data = fid.read(4)

            # Convert savedetflag to binary and create detflag array
            detflag_int = savedetflag & (2**8 - 1)  # bitand operation
            detflag = [
                (detflag_int >> i) & 1 for i in range(8)
            ]  # convert to binary array

            if endian == "little":
                detflag = detflag[::-1]  # flip for little endian (equivalent to fliplr)

            # Define data length array
            datalen = [1, hd[1], hd[1], hd[1], 3, 3, 1, 4]
            datlen = [
                detflag[i] * datalen[i] if i < len(detflag) else 0
                for i in range(len(datalen))
            ]

            # Read photon data
            total_elements = hd[6] * hd[3]  # savedphoton * colcount
            dat_bytes = fid.read(total_elements * np.dtype(dtype).itemsize)

            if len(dat_bytes) < total_elements * np.dtype(dtype).itemsize:
                break

            dat = np.frombuffer(dat_bytes, dtype=dtype).copy()
            dat = dat.reshape((hd[6], hd[3]))  # reshape to [savedphoton, colcount]

            # Apply unit conversion for path lengths
            if savedetflag and len(detflag) > 2 and detflag[2] > 0:
                start_col = sum(datlen[:2])
                end_col = sum(datlen[:3])
                dat[:, start_col:end_col] = dat[:, start_col:end_col] * unitmm
            elif savedetflag == 0:
                start_col = (
                    1 + hd[1]
                )  # 2 + hd[1] - 1 (converting from 1-based to 0-based)
                end_col = (
                    1 + 2 * hd[1]
                )  # 1 + 2*hd[1] - 1 (converting from 1-based to 0-based)
                dat[:, start_col:end_col] = dat[:, start_col:end_col] * unitmm

            # Append data
            if len(data) == 0:
                data = dat
            else:
                data = np.vstack([data, dat])

            # Read photon seeds if present
            if seedbyte > 0:
                try:
                    seed_bytes = fid.read(hd[6] * seedbyte)
                    if len(seed_bytes) == hd[6] * seedbyte:
                        seeds = np.frombuffer(seed_bytes, dtype=np.uint8)
                        seeds = seeds.reshape((hd[6], seedbyte))
                        if len(photonseed) == 0:
                            photonseed = seeds
                        else:
                            photonseed = np.vstack([photonseed, seeds])
                    else:
                        seedbyte = 0
                        warnings.warn("photon seed section is not found")
                except:
                    seedbyte = 0
                    warnings.warn("photon seed section is not found")

            # Adjust total photon count for respin
            if respin > 1:
                hd[4] = hd[4] * respin

            # Handle header accumulation
            if len(header) == 0:
                header = hd + [unitmm]
            else:
                current_header = hd + [unitmm]
                # Check consistency: version, maxmedia, detnum, colcount, unitmm
                if (
                    header[0] != current_header[0]
                    or header[1] != current_header[1]
                    or header[2] != current_header[2]
                    or header[3] != current_header[3]
                    or header[7] != current_header[7]
                ):
                    raise ValueError(
                        "loadmch can only load data generated from a single session"
                    )
                else:
                    # Accumulate totalphoton, detectedphoton, savedphoton
                    header[4] += current_header[4]  # totalphoton
                    header[5] += current_header[5]  # detectedphoton
                    header[6] += current_header[6]  # savedphoton

        except struct.error:
            break
        except Exception as e:
            if len(header) == 0:
                fid.close()
                raise e
            break

    fid.close()

    # Convert data to numpy array if it's a list
    if isinstance(data, list) and len(data) == 0:
        data = np.array([])

    # Create header struct
    headerstruct = {
        "version": header[0],
        "medianum": header[1],
        "detnum": header[2],
        "recordnum": header[3],
        "totalphoton": header[4],
        "detectedphoton": header[5],
        "savedphoton": header[6],
        "lengthunit": header[7],
        "seedbyte": seedbyte,
        "normalizer": normalizer,
        "respin": respin,
        "srcnum": srcnum,
        "savedetflag": savedetflag,
        "totalsource": totalsource,
    }

    # Return based on what's available
    if len(photonseed) > 0:
        return data, headerstruct, photonseed
    else:
        return data, headerstruct


def loadfile(fname, *varargin):
    """Read an MCX output file, choosing the reader by its extension.

    ``.nii`` files are read by :func:`loadnii`, ``.mc2`` files by :func:`loadmc2` (and
    returned as log10 values), ``.mch`` files by :func:`loadmch`, and other files as raw
    binary volumes by :func:`loadmc2`.

    Parameters
    ----------
    fname : str
        The file name.
    *varargin
        For ``.mc2`` and binary files, the ``dim`` and ``dataformat`` arguments of
        :func:`loadmc2`.

    Returns
    -------
    data : ndarray
        The data: a 3-D or 4-D volume, or the detected photon records.
    header : dict
        The metadata: the NIfTI header, the ``.mch`` header, or for ``.mc2`` files ``dim``,
        ``format`` and ``scale`` (``'log10'``).
    """

    # Parse file path and extension
    pathstr, name_with_ext = os.path.split(fname)
    name, ext = os.path.splitext(name_with_ext)

    # Convert extension to lowercase for case-insensitive comparison
    ext_lower = ext.lower()

    if ext_lower == ".nii":
        nii = loadnii(fname, *varargin)[0]
        data = nii["NIFTIData"]
        header = nii["NIFTIHeader"]

    elif ext_lower == ".mc2":
        data = loadmc2(fname, *varargin)
        data = np.log10(data)

        # Create header structure
        header = {}
        if len(varargin) >= 1:
            header["dim"] = varargin[0]
        header["format"] = data.dtype.name
        header["scale"] = "log10"

    elif ext_lower == ".mch":
        data, header = loadmch(fname)

    else:
        data = loadmc2(fname, *varargin)
        header = {}

    return data, header


def mcx2json(cfg, filestub):
    """Save a ``cfg`` dict as a JSON input file of the ``mcx`` command line.

    The volume, the source pattern and the other arrays are embedded in the JSON file as
    compressed JData arrays, except a volume combined with ``cfg['shapes']`` that has no
    ``Grid`` object, which is written to ``<filestub>_vol.bin``. Requires the ``jdata``
    package.

    Parameters
    ----------
    cfg : dict
        The simulation configuration (see ``pmcx.run``).
    filestub : str
        The name stub of the output files: ``<filestub>.json``, and ``<filestub>_vol.bin``
        when written; it is also the session ID.

    Raises
    ------
    ValueError
        If ``cfg['vol']`` has an unsupported format.
    """

    # Define the optodes: sources and detectors
    Optode = {}
    Optode["Source"] = {}
    Optode["Source"] = copycfg(cfg, "srcpos", Optode["Source"], "Pos")
    Optode["Source"] = copycfg(cfg, "srcdir", Optode["Source"], "Dir")
    Optode["Source"] = copycfg(cfg, "srciquv", Optode["Source"], "IQUV")
    Optode["Source"] = copycfg(cfg, "srcparam1", Optode["Source"], "Param1")
    Optode["Source"] = copycfg(cfg, "srcparam2", Optode["Source"], "Param2")
    Optode["Source"] = copycfg(cfg, "srctype", Optode["Source"], "Type")
    Optode["Source"] = copycfg(cfg, "srcnum", Optode["Source"], "SrcNum")
    Optode["Source"] = copycfg(cfg, "srcid", Optode["Source"], "ID")
    Optode["Source"] = copycfg(cfg, "lambda", Optode["Source"], "WaveLength")
    Optode["Source"] = copycfg(cfg, "angleinvcdf", Optode["Source"], "AngleInverseCDF")
    if "omega" in cfg and cfg["omega"] is not None and float(cfg["omega"]) > 0:
        # the JSON input stores the frequency in Hz, cfg['omega'] is 2*pi*f
        Optode["Source"]["Frequency"] = float(cfg["omega"]) / (2 * np.pi)

    if "detpos" in cfg and cfg["detpos"] is not None and len(cfg["detpos"]) > 0:
        Optode["Detector"] = []
        detpos = np.array(cfg["detpos"])
        for i in range(detpos.shape[0]):
            detector = {
                "Pos": detpos[i, :3].tolist(),
                "R": detpos[i, 3] if detpos.shape[1] > 3 else 1,
            }
            Optode["Detector"].append(detector)

        if len(Optode["Detector"]) == 1:
            Optode["Detector"] = [Optode["Detector"][0]]

    if "srcpattern" in cfg and cfg["srcpattern"] is not None:
        # a compressed JData array; mcx can not read a plain nested list
        Optode["Source"]["Pattern"] = jdataarray(
            np.array(cfg["srcpattern"], dtype=np.float32)
        )

    # Define the domain and optical properties
    Domain = {}
    Domain = copycfg(cfg, "issrcfrom0", Domain, "OriginType", 0)
    Domain = copycfg(cfg, "unitinmm", Domain, "LengthUnit")
    Domain = copycfg(cfg, "invcdf", Domain, "InverseCDF")

    # Convert prop matrix to Media list
    prop = np.array(cfg["prop"])
    Domain["Media"] = []
    for i in range(prop.shape[0]):
        media = {
            "mua": float(prop[i, 0]),
            "mus": float(prop[i, 1]),
            "g": float(prop[i, 2]),
            "n": float(prop[i, 3]),
        }
        Domain["Media"].append(media)

    if "polprop" in cfg and cfg["polprop"] is not None:
        polprop = np.array(cfg["polprop"])
        Domain["MieScatter"] = []
        for i in range(polprop.shape[0]):
            miescatter = {
                "mua": float(polprop[i, 0]),
                "radius": float(polprop[i, 1]),
                "rho": float(polprop[i, 2]),
                "nsph": float(polprop[i, 3]),
                "nmed": float(polprop[i, 4]),
            }
            Domain["MieScatter"].append(miescatter)

    Shapes = None
    if "shapes" in cfg and isinstance(cfg["shapes"], str):
        Shapes = json.loads(cfg["shapes"])
        Shapes = Shapes["Shapes"]

    if "vol" in cfg and cfg["vol"] is not None and "VolumeFile" not in Domain:
        vol = np.array(cfg["vol"])
        vol_dtype = vol.dtype

        # Determine MediaFormat based on volume data type and dimensions
        if vol_dtype in [np.uint8, np.int8]:
            Domain["MediaFormat"] = "byte"
            if vol.ndim == 4 and vol.shape[0] == 4:
                Domain["MediaFormat"] = "asgn_byte"
            elif vol.ndim == 4 and vol.shape[0] == 8:
                # the 8 bytes of each voxel, along the 1st axis, form one uint64
                vol = np.ascontiguousarray(np.moveaxis(vol.astype(np.uint8), 0, -1))
                vol = vol.view(np.uint64)[..., 0]
                cfg["vol"] = vol
                Domain["MediaFormat"] = "svmc"
        elif vol_dtype in [np.uint16, np.int16]:
            Domain["MediaFormat"] = "short"
            if vol.ndim == 4 and vol.shape[0] == 2:
                Domain["MediaFormat"] = "muamus_short"
        elif vol_dtype in [np.uint32, np.int32]:
            Domain["MediaFormat"] = "integer"
        elif vol_dtype in [np.float32, np.float64]:
            if vol_dtype == np.float64:
                vol = vol.astype(np.float32)
                cfg["vol"] = vol

            if vol.ndim == 4 and vol.shape[0] == 3:
                Domain["MediaFormat"] = "labelplus"
                vol = packlabelplus(vol, Domain.get("LengthUnit", 1))
                cfg["vol"] = vol
            elif np.all(np.mod(vol.flatten(), 1) == 0):
                if np.max(vol) < 256:
                    Domain["MediaFormat"] = "byte"
                    cfg["vol"] = vol.astype(np.uint8)
                else:
                    Domain["MediaFormat"] = "integer"
                    cfg["vol"] = vol.astype(np.uint32)
            elif vol.ndim == 4:
                if vol.shape[0] == 1:
                    Domain["MediaFormat"] = "mua_float"
                elif vol.shape[0] == 2:
                    Domain["MediaFormat"] = "muamus_float"
                elif vol.shape[0] == 4:
                    Domain["MediaFormat"] = "asgn_float"
        else:
            raise ValueError("cfg.vol has format that is not supported")

        Domain["Dim"] = list(vol.shape)
        if len(Domain["Dim"]) == 4:
            Domain["Dim"] = Domain["Dim"][1:]

        if Shapes is not None:
            # Check if Shapes contains "Grid"
            shapes_json = json.dumps(Shapes, separators=(",", ":"))
            if '"Grid"' not in shapes_json:
                Domain["VolumeFile"] = filestub + "_vol.bin"
                with open(Domain["VolumeFile"], "wb") as fid:
                    cfg["vol"].tobytes()
                    fid.write(cfg["vol"].tobytes())
        else:
            Domain["VolumeFile"] = ""
            Shapes = np.asarray(cfg["vol"])
            # move the record axis last; also drops the singleton of a [1,Nx,Ny,Nz] mua_float volume
            if Shapes.ndim == 4:
                Shapes = np.moveaxis(Shapes, 0, -1)
                if Shapes.shape[-1] == 1:
                    Shapes = Shapes[..., 0]

    # Define the simulation session flags
    Session = {}
    Session["ID"] = filestub
    Session = copycfg(cfg, "isreflect", Session, "DoMismatch")
    Session = copycfg(cfg, "issave2pt", Session, "DoSaveVolume")
    Session = copycfg(cfg, "issavedet", Session, "DoPartialPath")
    Session = copycfg(cfg, "issaveexit", Session, "DoSaveExit")
    Session = copycfg(cfg, "issaveseed", Session, "DoSaveSeed")
    Session = copycfg(cfg, "isnormalized", Session, "DoNormalize")
    Session = copycfg(cfg, "issaveref", Session, "DoSaveRef")
    Session = copycfg(cfg, "ismomentum", Session, "DoDCS")
    Session = copycfg(cfg, "isspecular", Session, "DoSpecular")
    Session = copycfg(cfg, "outputformat", Session, "OutputFormat")
    Session = copycfg(cfg, "outputtype", Session, "OutputType")
    Session = copycfg(cfg, "debuglevel", Session, "DebugFlag")
    Session = copycfg(cfg, "autopilot", Session, "DoAutoThread")
    Session = copycfg(cfg, "maxdetphoton", Session, "MaxDetPhoton")
    Session = copycfg(cfg, "bc", Session, "BCFlags")

    if (
        "savedetflag" in cfg
        and cfg["savedetflag"] is not None
        and isinstance(cfg["savedetflag"], str)
    ):
        cfg["savedetflag"] = cfg["savedetflag"].upper()
    Session = copycfg(cfg, "savedetflag", Session, "SaveDataMask")

    if "seed" in cfg and np.isscalar(cfg["seed"]):
        Session["RNGSeed"] = cfg["seed"]
    Session = copycfg(cfg, "nphoton", Session, "Photons")
    Session = copycfg(cfg, "minenergy", Session, "MinEnergy")
    Session = copycfg(cfg, "rootpath", Session, "RootPath")

    # Define the forward simulation settings
    Forward = {}
    Forward["T0"] = cfg["tstart"]
    Forward["T1"] = cfg["tend"]
    Forward["Dt"] = cfg["tstep"]

    # Assemble the complete input, save to a JSON or UBJSON input file
    mcxsession = {
        "Session": Session,
        "Forward": Forward,
        "Optode": Optode,
        "Domain": Domain,
    }

    if Shapes is not None:
        if isinstance(Shapes, np.ndarray):
            mcxsession["Shapes"] = jdataarray(Shapes)
        else:
            mcxsession["Shapes"] = Shapes

    from jdata import savejd

    savejd(mcxsession, filestub + ".json")


def jdataarray(data):
    """Encode a numpy array as a zlib-compressed, base64-encoded JData array object (a dict)."""
    import jdata

    obj = jdata.encode(
        np.asarray(data), compression="zlib", base64=True, compressarraysize=0
    )
    if isinstance(obj.get("_ArrayZipData_"), bytes):
        obj["_ArrayZipData_"] = obj["_ArrayZipData_"].decode("ascii")
    return obj


def packlabelplus(vol, unitinmm=1):
    """Pack a ``[3, Nx, Ny, Nz]`` float volume of ``[value; property index; label]`` records into
    the 32-bit labelplus format ``{[half: value][2-bit property index][14-bit label]}``, as
    mcxlab does.
    """
    vol = np.asarray(vol, dtype=np.float32)
    val = vol[0].copy()
    idx = vol[1]
    isscaled = (idx >= 1) & (
        idx <= 2
    )  # the same rule that mcxlab uses to scale the value by unitinmm
    val[isscaled] *= unitinmm
    bits = val.view(np.uint32)
    expo = ((bits >> 23) & 255).astype(np.int64)
    expo = np.where(expo > 112, (expo - 112) & 31, 0).astype(np.uint32)
    half = (((bits >> 31) << 5 | expo) << 10) | ((bits >> 13) & 1023)
    label = ((np.fix(idx).astype(np.uint32) & 3) << 14) | np.fix(vol[2]).astype(
        np.uint32
    )
    return (label | (half << 16)).astype(np.uint32)


def copycfg(cfg, name, outroot, outfield, defaultval=None):
    """Copy ``cfg[name]`` to ``outroot[outfield]``, if present, or set it to ``defaultval``.

    Parameters
    ----------
    cfg : dict
        The source dict.
    name : str
        The key in ``cfg``.
    outroot : dict
        The destination dict.
    outfield : str
        The key in ``outroot``.
    defaultval : optional
        The value to set when ``cfg`` has no ``name`` key.

    Returns
    -------
    outroot : dict
        The updated destination dict.
    """
    if defaultval is not None:
        outroot[outfield] = defaultval
    if name in cfg:
        outroot[outfield] = cfg[name]
    return outroot


def unpacklabelplus(packed, unitinmm=1):
    """Unpack the 32-bit labelplus format ``{[half: value][2-bit property index][14-bit label]}``
    written by :func:`mcx2json` into a ``[3, Nx, Ny, Nz]`` float32
    ``[value; property index; label]`` volume.
    """
    packed = np.asarray(packed).astype(np.uint32)
    val = (packed >> 16).astype(np.uint16).view(np.float16).astype(np.float32)
    idx = ((packed >> 14) & 3).astype(np.float32)
    isscaled = (idx >= 1) & (idx <= 2)  # mcx2json scaled these values by LengthUnit
    val[isscaled] /= unitinmm
    return np.stack([val, idx, (packed & 16383).astype(np.float32)])


def json2mcx(filename):
    """Convert a JSON input file of the ``mcx`` command line to a ``cfg`` dict.

    The volume (embedded, or read from ``Domain.VolumeFile``), the shapes, the source
    pattern and the detectors are converted to the ``cfg`` keys of ``pmcx.run``. Requires
    the ``jdata`` package.

    Parameters
    ----------
    filename : str or dict
        The JSON file name, or its already decoded content.

    Returns
    -------
    cfg : dict
        The simulation configuration, ready for :func:`pmcx.mcxlab` or ``pmcx.run``.
    """
    from jdata import loadjd, load as jload

    if isinstance(filename, str):
        json_data = jload(filename)
    elif isinstance(filename, dict):
        json_data = filename
    else:
        raise ValueError("first input is not supported")

    # Define the optodes: sources and detectors
    cfg = {}

    if "Optode" in json_data:
        if "Source" in json_data["Optode"]:
            cfg = icopycfg(cfg, "srcpos", json_data["Optode"]["Source"], "Pos")
            cfg = icopycfg(cfg, "srcdir", json_data["Optode"]["Source"], "Dir")
            if "srcdir" in cfg:  # normalize the direction of each source
                srcdir = np.array(cfg["srcdir"], dtype=float)
                rows = np.atleast_2d(srcdir)
                rows[:, :3] /= np.linalg.norm(rows[:, :3], axis=1, keepdims=True)
                cfg["srcdir"] = (rows if srcdir.ndim > 1 else rows[0]).tolist()
            cfg = icopycfg(cfg, "srcparam1", json_data["Optode"]["Source"], "Param1")
            cfg = icopycfg(cfg, "srcparam2", json_data["Optode"]["Source"], "Param2")
            cfg = icopycfg(cfg, "srctype", json_data["Optode"]["Source"], "Type")
            cfg = icopycfg(cfg, "srcnum", json_data["Optode"]["Source"], "SrcNum")
            cfg = icopycfg(cfg, "srcid", json_data["Optode"]["Source"], "ID")
            cfg = icopycfg(cfg, "srciquv", json_data["Optode"]["Source"], "IQUV")
            cfg = icopycfg(cfg, "lambda", json_data["Optode"]["Source"], "WaveLength")
            cfg = icopycfg(
                cfg, "angleinvcdf", json_data["Optode"]["Source"], "AngleInverseCDF"
            )
            if "Frequency" in json_data["Optode"]["Source"]:
                cfg["omega"] = (
                    2 * np.pi * float(json_data["Optode"]["Source"]["Frequency"])
                )

            if "Pattern" in json_data["Optode"]["Source"] and isinstance(
                json_data["Optode"]["Source"]["Pattern"], np.ndarray
            ):
                # a JData array, decoded by jdata.load
                cfg["srcpattern"] = json_data["Optode"]["Source"]["Pattern"].astype(
                    np.float32
                )
            elif "Pattern" in json_data["Optode"]["Source"] and isinstance(
                json_data["Optode"]["Source"]["Pattern"], dict
            ):
                pattern = json_data["Optode"]["Source"]["Pattern"]
                nz = pattern.get("Nz", 1)

                if isinstance(pattern["Data"], str):
                    with open(pattern["Data"], "rb") as fid:
                        pattern_data = np.frombuffer(fid.read(), dtype=np.float32)
                else:
                    pattern_data = np.array(pattern["Data"], dtype=np.float32)

                cfg["srcpattern"] = pattern_data.reshape(
                    (pattern["Nx"], pattern["Ny"], nz)
                )

        if (
            "Detector" in json_data["Optode"]
            and json_data["Optode"]["Detector"] is not None
            and len(json_data["Optode"]["Detector"]) > 0
        ):
            detectors = json_data["Optode"]["Detector"]
            if isinstance(detectors, list):
                # Convert list of detector dicts to matrix format
                detpos = []
                for det in detectors:
                    if isinstance(det, dict):
                        pos = det.get("Pos", [0, 0, 0])
                        r = det.get("R", 1)
                        detpos.append(pos + [r])
                    else:
                        detpos.append(det)
                cfg["detpos"] = detpos
            else:
                # Handle single detector case
                if isinstance(detectors, dict):
                    pos = detectors.get("Pos", [0, 0, 0])
                    r = detectors.get("R", 1)
                    cfg["detpos"] = [pos + [r]]

    # Define the domain and optical properties
    if "Domain" in json_data:
        cfg = icopycfg(cfg, "issrcfrom0", json_data["Domain"], "OriginType")
        cfg = icopycfg(cfg, "unitinmm", json_data["Domain"], "LengthUnit")
        cfg = icopycfg(cfg, "invcdf", json_data["Domain"], "InverseCDF")
        if "angleinvcdf" not in cfg:  # older mcx2json versions saved it in Domain
            cfg = icopycfg(cfg, "angleinvcdf", json_data["Domain"], "AngleInverseCDF")
        if "MieScatter" in json_data["Domain"]:
            mie = json_data["Domain"]["MieScatter"]
            mie = mie if isinstance(mie, list) else [mie]
            cfg["polprop"] = [
                [m["mua"], m["radius"], m["rho"], m["nsph"], m["nmed"]] for m in mie
            ]

        if "Media" in json_data["Domain"]:
            media = json_data["Domain"]["Media"]
            if isinstance(media, list):
                # Convert list of media dicts to matrix format
                prop = []
                for m in media:
                    if isinstance(m, dict):
                        prop.append(
                            [
                                m.get("mua", 0),
                                m.get("mus", 0),
                                m.get("g", 0),
                                m.get("n", 1),
                            ]
                        )
                    else:
                        prop.append(m)
                cfg["prop"] = prop
            else:
                cfg["prop"] = media

    if "Shapes" in json_data and isinstance(json_data["Shapes"], np.ndarray):
        # mcx2json saves cfg["vol"] as a JData array in Shapes, with the leading
        # (per-voxel record) dimension of a 4-D volume moved to the end
        vol = json_data["Shapes"]
        mediaformat = str(json_data.get("Domain", {}).get("MediaFormat", "")).lower()
        if vol.ndim == 4:
            vol = np.moveaxis(vol, -1, 0)
        if mediaformat == "svmc":
            vol = np.ascontiguousarray(vol, dtype=np.uint64)
            vol = np.moveaxis(vol[..., np.newaxis].view(np.uint8), -1, 0)
        elif mediaformat == "labelplus":
            vol = unpacklabelplus(vol, json_data["Domain"].get("LengthUnit", 1))
        elif mediaformat == "mua_float":
            vol = vol.astype(np.float32)[np.newaxis, ...]
        cfg["vol"] = vol
    elif "Shapes" in json_data:
        cfg["shapes"] = json.dumps({"Shapes": json_data["Shapes"]})

    format_key = None
    if "Domain" in json_data and json_data["Domain"].get("VolumeFile"):
        volume_file = json_data["Domain"]["VolumeFile"]
        fpath, fname = os.path.split(volume_file)
        fname, fext = os.path.splitext(fname)

        if fext == ".json":
            if "Dim" in json_data["Domain"]:
                cfg["vol"] = np.zeros(json_data["Domain"]["Dim"], dtype=np.uint8)
            volume_json = jload(volume_file)
            cfg["shapes"] = json.dumps(volume_json)

        elif fext == ".bin":
            bytelen = 1
            mediaclass = np.uint8

            if "MediaFormat" in json_data["Domain"]:
                format_map = {
                    "byte": (1, np.uint8),
                    "short": (2, np.uint16),
                    "integer": (4, np.uint32),
                    "muamus_float": (8, np.float32),
                    "mua_float": (4, np.float32),
                    "muamus_half": (4, np.uint16),
                    "asgn_byte": (4, np.uint8),
                    "muamus_short": (4, np.uint16),
                    "svmc": (8, np.uint8),
                    "asgn_float": (16, np.float32),
                }

                format_key = json_data["Domain"]["MediaFormat"].lower()
                if format_key in format_map:
                    bytelen, mediaclass = format_map[format_key]
                else:
                    raise ValueError("incorrect Domain.MediaFormat setting")

            # Load binary volume file
            with open(volume_file, "rb") as fid:
                vol_data = np.frombuffer(fid.read(), dtype=np.uint8)

            # Convert to appropriate data type
            vol_data = vol_data.view(mediaclass)

            # Reshape volume
            dim = json_data["Domain"]["Dim"]
            total_elements = len(vol_data)
            vol_shape = [total_elements // np.prod(dim)] + dim
            cfg["vol"] = vol_data.reshape(vol_shape)

            if cfg["vol"].shape[0] == 1:
                if format_key != "mua_float":
                    cfg["vol"] = np.squeeze(cfg["vol"], axis=0)

        elif fext in (".nii", ".jnii", ".nii", ".gz", ".img", ".bnii"):
            jnii = loadjd(volume_file)
            cfg["vol"] = jnii["NIFTIData"]

    elif "shapes" not in cfg and "vol" not in cfg:
        cfg["vol"] = np.zeros((60, 60, 60), dtype=np.uint8)

    # Define the simulation session flags
    if "Session" in json_data:
        cfg = icopycfg(cfg, "session", json_data["Session"], "ID")
        cfg = icopycfg(cfg, "isreflect", json_data["Session"], "DoMismatch")
        cfg = icopycfg(cfg, "issave2pt", json_data["Session"], "DoSaveVolume")
        cfg = icopycfg(cfg, "issavedet", json_data["Session"], "DoPartialPath")
        cfg = icopycfg(cfg, "issaveexit", json_data["Session"], "DoSaveExit")
        cfg = icopycfg(cfg, "issaveseed", json_data["Session"], "DoSaveSeed")
        cfg = icopycfg(cfg, "isnormalized", json_data["Session"], "DoNormalize")
        cfg = icopycfg(cfg, "issaveref", json_data["Session"], "DoSaveRef")
        cfg = icopycfg(cfg, "ismomentum", json_data["Session"], "DoDCS")
        cfg = icopycfg(cfg, "isspecular", json_data["Session"], "DoSpecular")
        cfg = icopycfg(cfg, "maxdetphoton", json_data["Session"], "MaxDetPhoton")
        cfg = icopycfg(cfg, "minenergy", json_data["Session"], "MinEnergy")
        cfg = icopycfg(cfg, "bc", json_data["Session"], "BCFlags")
        cfg = icopycfg(cfg, "savedetflag", json_data["Session"], "SaveDataMask")
        cfg = icopycfg(cfg, "outputformat", json_data["Session"], "OutputFormat")
        cfg = icopycfg(cfg, "outputtype", json_data["Session"], "OutputType")

        if "outputtype" in cfg and len(str(cfg["outputtype"])) == 1:
            otypemap = {
                "x": "flux",
                "f": "fluence",
                "e": "energy",
                "j": "jacobian",
                "p": "nscat",
                "m": "wm",
                "r": "rf",
                "l": "length",
                "s": "rfmus",
                "t": "wltof",
                "b": "wptof",
                "a": "adjoint",
                "d": "adjoint_dcoeff",
                "u": "adjoint_mus",
                "v": "adjoint_musp",
                "w": "adjoint_mua_d",
                "q": "adjoint_mua_musp",
            }

            if cfg["outputtype"] not in otypemap:
                raise ValueError(f"output type {cfg['outputtype']} is not supported")
            cfg["outputtype"] = otypemap[cfg["outputtype"]]

        cfg = icopycfg(cfg, "debuglevel", json_data["Session"], "DebugFlag")
        if "debuglevel" not in cfg:  # older mcx2json versions used "Debug"
            cfg = icopycfg(cfg, "debuglevel", json_data["Session"], "Debug")
        cfg = icopycfg(cfg, "autopilot", json_data["Session"], "DoAutoThread")
        cfg = icopycfg(cfg, "seed", json_data["Session"], "RNGSeed")

        if (
            "seed" in cfg
            and isinstance(cfg["seed"], str)
            and re.search(r"\.mch$", cfg["seed"])
        ):
            # Would need to implement loadmch function for MCH file support
            raise NotImplementedError(
                "MCH file format not implemented - requires loadmch function"
            )

        cfg = icopycfg(cfg, "nphoton", json_data["Session"], "Photons")
        cfg = icopycfg(cfg, "rootpath", json_data["Session"], "RootPath")

    # Define the forward simulation settings
    if "Forward" in json_data:
        forward = json_data["Forward"]
        if "T0" in forward:
            cfg["tstart"] = forward["T0"]
        cfg = icopycfg(cfg, "tstart", forward, "T0")
        cfg = icopycfg(cfg, "tend", forward, "T1")
        cfg = icopycfg(cfg, "tstep", forward, "Dt")

    return cfg


def icopycfg(cfg, name, outroot, outfield, defaultval=None):
    """Copy ``outroot[outfield]`` to ``cfg[name]``, if present, or set it to ``defaultval``.

    Parameters
    ----------
    cfg : dict
        The destination dict.
    name : str
        The key in ``cfg``.
    outroot : dict
        The source dict.
    outfield : str
        The key in ``outroot``.
    defaultval : optional
        The value to set when ``outroot`` has no ``outfield`` key.

    Returns
    -------
    cfg : dict
        The updated destination dict.
    """
    if defaultval is not None and outfield not in outroot:
        outroot[outfield] = defaultval
    if outfield in outroot:
        cfg[name] = outroot[outfield]
    return cfg


def loadnii(*args, **kwargs):
    """Read a NIfTI (``.nii``, ``.nii.gz``) or JNIfTI (``.jnii``, ``.bnii``) file.

    A thin wrapper of ``jdata.loadjd``; requires the ``jdata`` package.

    Parameters
    ----------
    *args, **kwargs
        The arguments of ``jdata.loadjd``, the first being the file name.

    Returns
    -------
    data
        The decoded file, as ``jdata.loadjd`` returns it.
    """
    from jdata import loadjd

    return loadjd(*args, **kwargs)
