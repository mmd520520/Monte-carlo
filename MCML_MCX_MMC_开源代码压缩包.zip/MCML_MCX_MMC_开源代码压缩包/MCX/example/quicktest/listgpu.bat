..\..\bin\mcx.exe -L
